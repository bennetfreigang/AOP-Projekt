// File: org/quirkle/entities/ExampleEntity.java
package org.quirkle.entities;

import org.quirkle.resourceEngine.Entity;
import org.quirkle.resourceEngine.SceneManager;
import org.quirkle.scenes.ExampleScene2;

public class ExampleEntity extends Entity {

    public ExampleEntity() {
        this.texturePath = "/assets/textures/example.png";
        this.hasTexture = true;
        this.scaleX = 0.5;
        this.scaleY = 0.5;
    }

    @Override
    protected void onInit() {
        // Initial setup logic (if needed)
    }

    @Override
    protected void onTick(double deltaTime) {
        // Check backend-calculated input helper
    	if (isMouseHovering()) {
    		System.out.println("hovering");
    	}
        if (isMouseClicked()) {
        	System.out.println("pressed");
            //SceneManager.getInstance().switchToScene(new ExampleScene2());
        }
    }
}
