// File: org/quirkle/entities/ExampleEntityMove.java
package org.quirkle.entities;

import org.quirkle.resourceEngine.Entity;
import org.quirkle.resourceEngine.InputManager;
import org.quirkle.resourceEngine.Vector2;

public class ExampleEntityMove extends Entity {

    public ExampleEntityMove() {
        this.texturePath = "/assets/textures/example.png";
        this.hasTexture = true;
        this.speed = 300.0; // pixels per second
        this.scaleX = 0.5;
        this.scaleY = 0.5;
    }

    @Override
    protected void onInit() {
        // Initial setup
    }

    @Override
    protected void onTick(double deltaTime) {
        // Continuously set target to mouse cursor position
        Vector2 mousePos = InputManager.getMousePosition();

        // Adjust targetPos so entity center aligns with cursor
        Vector2 halfSize = getScaledDimensions().multiply(0.5);
        this.targetPos = mousePos.minus(halfSize);
    }
}
