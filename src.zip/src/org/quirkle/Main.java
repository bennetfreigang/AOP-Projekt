// File: org/quirkle/Main.java
package org.quirkle;

import org.quirkle.resourceEngine.*;
import org.quirkle.scenes.ExampleScene;

import javax.swing.*;
import java.awt.*;

public class Main {
    public static void main(String[] args) {
        // Initialize the engine with window size and title
        EngineConfig.setWindowSize(1500, 1000);
        EngineConfig.setWindowTitle("Quirkle Engine");
        
        // Create the main window
        JFrame frame = new JFrame(EngineConfig.getWindowTitle());
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setResizable(false);
        
        // Create the scene and setup the render panel
        Scene scene = new ExampleScene();
        RenderPanel panel = new RenderPanel(scene, 1.0/60.0);
        
        // Add panel to frame
        frame.add(panel);
        frame.pack();
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
        
        // Start the game loop
        GameLoop gameLoop = new GameLoop(scene, panel, 60);
        gameLoop.start();
        
        // Initialize the scene manager with the first scene
        SceneManager.getInstance().switchToScene(scene);
    }
}
