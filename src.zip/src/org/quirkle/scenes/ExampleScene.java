// File: org/quirkle/scenes/ExampleScene.java
package org.quirkle.scenes;

import org.quirkle.entities.ExampleEntity;
import org.quirkle.resourceEngine.Scene;
import org.quirkle.resourceEngine.Vector2;

public class ExampleScene extends Scene {
    private ExampleEntity exampleEntity;

    public ExampleScene() {
        super();

        exampleEntity = new ExampleEntity();
        addEntity(exampleEntity);

        // Force resolution of graphics to get actual dimensions
        exampleEntity.resolveGraphics();
        
        // Calculate proper center position (accounting for entity dimensions)
        Vector2 viewportCenter = getViewportCenter();
        double entityCenterX = viewportCenter.x - (exampleEntity.getScaledDimensions().x / 2.0);
        double entityCenterY = viewportCenter.y - (exampleEntity.getScaledDimensions().y / 2.0);
        
        Vector2 centeredPos = new Vector2(entityCenterX, entityCenterY);
        exampleEntity.currentPos = centeredPos;
        exampleEntity.targetPos = centeredPos;
    }
}
