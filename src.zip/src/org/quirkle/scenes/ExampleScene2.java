// File: org/quirkle/scenes/ExampleScene2.java
package org.quirkle.scenes;

import org.quirkle.entities.ExampleEntityMove;
import org.quirkle.resourceEngine.Scene;
import org.quirkle.resourceEngine.Vector2;

public class ExampleScene2 extends Scene {
    private ExampleEntityMove moveEntity;

    public ExampleScene2() {
        super();

        moveEntity = new ExampleEntityMove();
        addEntity(moveEntity);

        // Force resolution of graphics to get actual dimensions
        moveEntity.resolveGraphics();
        
        // Start at center
        Vector2 viewportCenter = getViewportCenter();
        double entityCenterX = viewportCenter.x - (moveEntity.getScaledDimensions().x / 2.0);
        double entityCenterY = viewportCenter.y - (moveEntity.getScaledDimensions().y / 2.0);
        
        Vector2 centeredPos = new Vector2(entityCenterX, entityCenterY);
        moveEntity.currentPos = centeredPos;
        moveEntity.targetPos = centeredPos;
    }

    @Override
    public void update(double deltaTime) {
        super.update(deltaTime);
        
        // Move towards cursor position every tick
        Vector2 cursorPos = getMousePosition();
        moveEntity.targetPos = cursorPos;
    }
}
