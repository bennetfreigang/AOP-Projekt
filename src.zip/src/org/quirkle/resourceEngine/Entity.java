// File: org/quirkle/resourceEngine/Entity.java
package org.quirkle.resourceEngine;

import java.awt.image.BufferedImage;

public abstract class Entity {
    public Vector2 currentPos = new Vector2(0, 0);
    public Vector2 targetPos = new Vector2(0, 0);
    public double speed = 0.0; //0 : instant movement

    public double width;
    public double height;
    public double scaleX = 1.0;
    public double scaleY = 1.0;

    public String texturePath;
    public boolean hasTexture = false;
    public transient BufferedImage texture;

    private boolean isInitialized = false;

    public Entity() {
        // Initialize the entity
        onInit();
        isInitialized = true;
    }

    protected abstract void onInit();

    protected void onTick(double deltaTime) {
        // Override this in subclasses to implement custom behavior
    }

    public void update(double deltaTime) {
        if (!isInitialized) return;
        
        // Update the entity's position based on speed and target
        if (currentPos == null || targetPos == null) return;
        if (currentPos.x == targetPos.x && currentPos.y == targetPos.y) return; //goal reached

        if (speed <= 0) {
            currentPos = targetPos;
        } else {
            double dx = targetPos.x - currentPos.x;
            double dy = targetPos.y - currentPos.y;

            double distance = Math.sqrt(dx * dx + dy * dy);

            //max distance travel per frame
            double maxDistanceThisFrame = speed * deltaTime;

            if (distance <= maxDistanceThisFrame) {
                currentPos = targetPos;
            } else {
                double ratio = maxDistanceThisFrame / distance;
                double newX = currentPos.x + dx * ratio;
                double newY = currentPos.y + dy * ratio;
                currentPos = new Vector2(newX, newY);
            }
        }
        
        // Call the tick method for custom behavior
        onTick(deltaTime);
    }

    public Vector2 getCenteredPosition(double centerX, double centerY) {
        double entityCenterX = centerX - (getScaledDimensions().x / 2.0);
        double entityCenterY = centerY - (getScaledDimensions().y / 2.0);
        return new Vector2(entityCenterX, entityCenterY);
    }

    public void resolveGraphics() {
        if (hasTexture && texturePath != null && texture == null) {
            this.texture = AssetManager.getTexture(texturePath);
            if (texture != null) {
                this.width = texture.getWidth();
                this.height = texture.getHeight();
            }
        }
    }

    public Vector2 getScaledDimensions() {
        return new Vector2(width * scaleX, height * scaleY);
    }

    // Helper methods for frontend use
    public boolean isMouseHovering() {
        Vector2 mousePos = InputManager.getMousePosition();
        Vector2 scaledDims = getScaledDimensions();
        
        return mousePos.x >= currentPos.x && 
               mousePos.x <= currentPos.x + scaledDims.x &&
               mousePos.y >= currentPos.y && 
               mousePos.y <= currentPos.y + scaledDims.y;
    }

    public boolean isMouseClicked() {
        return InputManager.isMouseClicked() && isMouseHovering();
    }
}
