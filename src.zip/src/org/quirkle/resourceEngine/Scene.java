// File: org/quirkle/resourceEngine/Scene.java
package org.quirkle.resourceEngine;

import java.awt.*;
import java.awt.event.MouseEvent;
import java.util.concurrent.CopyOnWriteArrayList;

public class Scene {
    protected final CopyOnWriteArrayList<Entity> entities = new CopyOnWriteArrayList<>();
    protected InputManager inputManager;
    protected int viewportWidth;
    protected int viewportHeight;

    public Scene() {
        this.inputManager = new InputManager();
        this.viewportWidth = EngineConfig.getWindowWidth();
        this.viewportHeight = EngineConfig.getWindowHeight();
    }

    public Scene(int width, int height) {
        this();
        this.viewportWidth = width;
        this.viewportHeight = height;
    }

    public void setViewportSize(int width, int height) {
        this.viewportWidth = width;
        this.viewportHeight = height;
    }

    public int getViewportWidth() {
        return viewportWidth;
    }

    public int getViewportHeight() {
        return viewportHeight;
    }

    public Vector2 getViewportCenter() {
        return new Vector2(viewportWidth / 2.0, viewportHeight / 2.0);
    }

    public Vector2 getMousePosition() {
        return inputManager.getMousePosition();
    }

    public void addEntity(Entity entity) {
        entities.add(entity);
    }

    public void removeEntity(Entity entity) {
        entities.remove(entity);
    }

    public void update(double deltaTime) {
        // Update input manager
        inputManager.update();
        
        // Update all entities
        for (Entity e : entities) {
            e.update(deltaTime);
        }
    }

    public void render(Graphics2D g) {
        for (Entity e : entities) {
            e.resolveGraphics();
            if (e.hasTexture && e.texture != null) {
                // Get scaled dimensions
                Vector2 scaledDims = e.getScaledDimensions();
                g.drawImage(e.texture,
                        (int) e.currentPos.x,
                        (int) e.currentPos.y,
                        (int) scaledDims.x,
                        (int) scaledDims.y,
                        null);
            }
        }
    }

    public void onEnter() {}
    public void onPause() {}
    public void onResume() {}
    public void onExit() {
        entities.clear();
    }
}
