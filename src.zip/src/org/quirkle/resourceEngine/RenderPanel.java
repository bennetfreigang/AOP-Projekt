// File: org/quirkle/resourceEngine/RenderPanel.java
package org.quirkle.resourceEngine;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ComponentAdapter;
import java.awt.event.ComponentEvent;

public class RenderPanel extends JPanel {
    private final Scene scene;
    private double deltaTime;

    public RenderPanel(Scene scene, double deltaTime) {
        this.scene = scene;
        this.deltaTime = deltaTime;
        this.setPreferredSize(new Dimension(
                EngineConfig.getWindowWidth(),
                EngineConfig.getWindowHeight()
        ));

        // Add resize listener
        this.addComponentListener(new ComponentAdapter() {
            @Override
            public void componentResized(ComponentEvent e) {
                Dimension size = e.getComponent().getSize();
                scene.setViewportSize(size.width, size.height);
            }
        });
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2d = (Graphics2D) g.create();
        scene.render(g2d);
        g2d.dispose();
    }
}
