// File: org/quirkle/resourceEngine/SceneManager.java
package org.quirkle.resourceEngine;

import java.util.Stack;

public class SceneManager {
    private static SceneManager instance;
    private final Stack<Scene> sceneStack = new Stack<>();
    private Scene currentScene;

    private SceneManager() {}

    public static SceneManager getInstance() {
        if (instance == null) {
            instance = new SceneManager();
        }
        return instance;
    }

    public void pushScene(Scene scene) {
        if (!sceneStack.isEmpty()) {
            sceneStack.peek().onPause();
        }
        sceneStack.push(scene);
        scene.onEnter();
        this.currentScene = scene;
    }

    public void popScene() {
        if (!sceneStack.isEmpty()) {
            Scene old = sceneStack.pop();
            old.onExit();
            if (!sceneStack.isEmpty()) {
                Scene newScene = sceneStack.peek();
                newScene.onResume();
                this.currentScene = newScene;
            } else {
                this.currentScene = null;
            }
        }
    }

    public Scene getCurrentScene() {
        return currentScene;
    }

    public void switchToScene(Scene scene) {
        if (!sceneStack.isEmpty()) {
            Scene oldScene = sceneStack.pop();
            oldScene.onExit();
        }
        sceneStack.push(scene);
        scene.onEnter();
        this.currentScene = scene;
    }
}
