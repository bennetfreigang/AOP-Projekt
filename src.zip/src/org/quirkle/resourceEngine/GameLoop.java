// File: org/quirkle/resourceEngine/GameLoop.java
package org.quirkle.resourceEngine;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class GameLoop implements ActionListener {
    private final Scene scene;
    private final RenderPanel panel;
    private final Timer timer;
    private final double deltaTime;

    public GameLoop(Scene scene, RenderPanel panel, int fps) {
        this.scene = scene;
        this.panel = panel;
        this.deltaTime = 1.0 / fps;
        this.timer = new Timer(1000 / fps, this);
    }

    public void start() {
        timer.start();
    }

    public void stop() {
        timer.stop();
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        scene.update(deltaTime);
        panel.repaint();
    }
}
