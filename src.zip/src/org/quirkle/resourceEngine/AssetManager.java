// File: org/quirkle/resourceEngine/AssetManager.java
package org.quirkle.resourceEngine;

import javax.imageio.ImageIO;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;

public class AssetManager {
    private static final Map<String, BufferedImage> cache = new HashMap<>();

    public static BufferedImage getTexture(String path) {
        if (path == null || path.isEmpty()) {
            return null;
        }

        if (cache.containsKey(path)) return cache.get(path);

        try (InputStream in = AssetManager.class.getResourceAsStream(path)) {
            if (in == null) {
                System.err.println("[Warning] ResourceEngine: Could not find texture in ClassPath: " + path);
                return getFallbackTexture();
            }
            BufferedImage img = ImageIO.read(in);
            cache.put(path, img);
            return img;
        } catch (IOException e) {
            System.err.println("[ERROR] ResourceEngine: Could not load texture: " + path);
            return getFallbackTexture();
        }
    }

    private static BufferedImage fallbackTexture = null;

    private static BufferedImage getFallbackTexture() {
        if (fallbackTexture == null) {
            fallbackTexture = new BufferedImage(32, 32, BufferedImage.TYPE_INT_RGB);
            Graphics2D g = fallbackTexture.createGraphics();
            g.setColor(Color.MAGENTA);
            g.fillRect(0, 0, 16, 16);
            g.fillRect(16, 16, 16, 16);
            g.setColor(Color.BLACK);
            g.fillRect(16, 0, 16, 16);
            g.fillRect(0, 16, 16, 16);
            g.dispose();
        }
        return fallbackTexture;
    }
}
