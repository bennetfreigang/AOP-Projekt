// File: org/quirkle/resourceEngine/EngineConfig.java
package org.quirkle.resourceEngine;

public class EngineConfig {
    public static int WINDOW_WIDTH = 800;
    public static int WINDOW_HEIGHT = 600;
    public static String WINDOW_TITLE = "Quirkle Engine";

    public static void setWindowSize(int width, int height) {
        WINDOW_WIDTH = width;
        WINDOW_HEIGHT = height;
    }

    public static void setWindowTitle(String title) {
        WINDOW_TITLE = title;
    }

    public static int getWindowWidth() {
        return WINDOW_WIDTH;
    }

    public static int getWindowHeight() {
        return WINDOW_HEIGHT;
    }

    public static String getWindowTitle() {
        return WINDOW_TITLE;
    }

    public static Vector2 getViewportCenter() {
        return new Vector2(WINDOW_WIDTH / 2.0, WINDOW_HEIGHT / 2.0);
    }
}
