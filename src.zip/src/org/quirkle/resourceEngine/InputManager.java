// File: org/quirkle/resourceEngine/InputManager.java
package org.quirkle.resourceEngine;

import java.awt.event.*;
import java.util.concurrent.CopyOnWriteArrayList;

public class InputManager {
    private final CopyOnWriteArrayList<KeyListener> keyListeners = new CopyOnWriteArrayList<>();
    private final CopyOnWriteArrayList<MouseListener> mouseListeners = new CopyOnWriteArrayList<>();
    private final CopyOnWriteArrayList<MouseMotionListener> mouseMotionListeners = new CopyOnWriteArrayList<>();
    
    private Vector2 mousePosition = new Vector2(0, 0);
    private boolean[] keys = new boolean[256];
    private boolean mousePressed = false;
    private boolean mouseClicked = false;

    public void addKeyListener(KeyListener listener) {
        keyListeners.add(listener);
    }

    public void addMouseListener(MouseListener listener) {
        mouseListeners.add(listener);
    }

    public void addMouseMotionListener(MouseMotionListener listener) {
        mouseMotionListeners.add(listener);
    }

    public void processKeyEvents(KeyEvent e) {
        keyListeners.forEach(l -> l.keyPressed(e));
    }

    public void processMouseEvents(MouseEvent e) {
        mouseListeners.forEach(l -> l.mouseClicked(e));
        updateMousePosition(e);
        
        if (e.getButton() == MouseEvent.BUTTON1 && e.getID() == MouseEvent.MOUSE_PRESSED) {
            mousePressed = true;
            mouseClicked = true;
        } else if (e.getButton() == MouseEvent.BUTTON1 && e.getID() == MouseEvent.MOUSE_RELEASED) {
            mousePressed = false;
        }
    }

    public void processMouseMotionEvents(MouseEvent e) {
        mouseMotionListeners.forEach(l -> l.mouseDragged(e));
        updateMousePosition(e);
    }

    private void updateMousePosition(MouseEvent e) {
        mousePosition = new Vector2(e.getX(), e.getY());
    }

    public Vector2 getMousePosition() {
        return mousePosition;
    }

    public void setKeyPressed(int keyCode, boolean pressed) {
        if (keyCode >= 0 && keyCode < keys.length) {
            keys[keyCode] = pressed;
        }
    }

    public boolean isKeyPressed(int keyCode) {
        if (keyCode >= 0 && keyCode < keys.length) {
            return keys[keyCode];
        }
        return false;
    }

    public boolean isMousePressed() {
        return mousePressed;
    }

    public boolean isMouseClicked() {
        boolean result = mouseClicked;
        mouseClicked = false; // Reset after checking
        return result;
    }

    public void update() {
        // Reset mouse click flag at the start of each frame
        mouseClicked = false;
    }
}
