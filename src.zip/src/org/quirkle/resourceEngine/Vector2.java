// File: org/quirkle/resourceEngine/Vector2.java
package org.quirkle.resourceEngine;

public class Vector2 {
    public final double x, y;

    public Vector2(double x, double y) {
        this.x = x;
        this.y = y;
    }

    public Vector2 add(Vector2 other) {
        return new Vector2(x + other.x, y + other.y);
    }

    public Vector2 minus(Vector2 other) {
        return new Vector2(x - other.x, y - other.y);
    }

    public Vector2 multiply(double scalar) {
        return new Vector2(x * scalar, y * scalar);
    }

    public Vector2 moveTowards(Vector2 target, double maxDistanceDelta) {
        double dx = target.x - x;
        double dy = target.y - y;
        double distance = Math.sqrt(dx * dx + dy * dy);

        if (distance <= maxDistanceDelta || distance == 0) {
            return new Vector2(target.x, target.y);
        }

        double ratio = maxDistanceDelta / distance;
        return new Vector2(x + dx * ratio, y + dy * ratio);
    }

    public static Vector2 lerp(Vector2 a, Vector2 b, double alpha) {
        double t = Math.max(0, Math.min(1, alpha));
        return new Vector2(
                a.x + (b.x - a.x) * t,
                a.y + (b.y - a.y) * t
        );
    }

    public double distance(Vector2 other) {
        double dx = x - other.x;
        double dy = y - other.y;
        return Math.sqrt(dx * dx + dy * dy);
    }

    @Override
    public String toString() {
        return String.format("(%.1f, %.1f)", x, y);
    }
}
